create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_message_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_permission_id_seq', 58, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_user_id_seq', 62, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: budget_budget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('budget_budget_id_seq', 9, true);


--
-- Name: budget_budgetline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('budget_budgetline_id_seq', 58, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('django_content_type_id_seq', 19, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('history_history_id_seq', 3, true);


--
-- Name: history_history_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('history_history_items_id_seq', 1, true);


--
-- Name: infos_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('infos_info_id_seq', 25, true);


--
-- Name: issues_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('issues_issue_id_seq', 104, true);


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('order_order_id_seq', 34, true);


--
-- Name: order_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('order_order_items_id_seq', 54, true);


--
-- Name: order_orderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('order_orderitem_id_seq', 67, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('product_product_id_seq', 3284, true);


--
-- Name: provider_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('provider_provider_id_seq', 52, true);


--
-- Name: provider_provider_users_in_charge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('provider_provider_users_in_charge_id_seq', 1, false);


--
-- Name: team_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('team_team_id_seq', 15, true);


--
-- Name: team_teammember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: briois
--

SELECT pg_catalog.setval('team_teammember_id_seq', 61, true);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_group (id, name) FROM stdin;
\.
copy auth_group (id, name)  from '$$PATH$$/2048.dat' ;
--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
\.
copy django_content_type (id, name, app_label, model)  from '$$PATH$$/2053.dat' ;
--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
copy auth_permission (id, name, content_type_id, codename)  from '$$PATH$$/2046.dat' ;
--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
copy auth_group_permissions (id, group_id, permission_id)  from '$$PATH$$/2047.dat' ;
--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
\.
copy auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined)  from '$$PATH$$/2051.dat' ;
--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_message (id, user_id, message) FROM stdin;
\.
copy auth_message (id, user_id, message)  from '$$PATH$$/2052.dat' ;
--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
copy auth_user_groups (id, user_id, group_id)  from '$$PATH$$/2050.dat' ;
--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
copy auth_user_user_permissions (id, user_id, permission_id)  from '$$PATH$$/2049.dat' ;
--
-- Data for Name: team_team; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY team_team (id, name, fullname, is_active) FROM stdin;
\.
copy team_team (id, name, fullname, is_active)  from '$$PATH$$/2057.dat' ;
--
-- Data for Name: budget_budget; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY budget_budget (id, team_id, name, default_origin, budget_type, default_nature, tva_code, domain, is_active) FROM stdin;
\.
copy budget_budget (id, team_id, name, default_origin, budget_type, default_nature, tva_code, domain, is_active)  from '$$PATH$$/2067.dat' ;
--
-- Data for Name: budget_budgetline; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY budget_budgetline (id, team, order_id, orderitem_id, budget_id, budget, number, date, nature, budget_type, origin, provider, offer, product, reference, quantity, product_price, credit, debit, confidential, is_active) FROM stdin;
\.
copy budget_budgetline (id, team, order_id, orderitem_id, budget_id, budget, number, date, nature, budget_type, origin, provider, offer, product, reference, quantity, product_price, credit, debit, confidential, is_active)  from '$$PATH$$/2068.dat' ;
--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
\.
copy django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message)  from '$$PATH$$/2056.dat' ;
--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
copy django_session (session_key, session_data, expire_date)  from '$$PATH$$/2054.dat' ;
--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY django_site (id, domain, name) FROM stdin;
\.
copy django_site (id, domain, name)  from '$$PATH$$/2055.dat' ;
--
-- Data for Name: history_history; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY history_history (id, team, provider, number, price, budget, date_delivered, date_created) FROM stdin;
\.
copy history_history (id, team, provider, number, price, budget, date_delivered, date_created)  from '$$PATH$$/2066.dat' ;
--
-- Data for Name: order_orderitem; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY order_orderitem (id, username, product_id, name, provider, origin, packaging, reference, offer_nb, nomenclature, price, cost_type, quantity, is_confidential) FROM stdin;
\.
copy order_orderitem (id, username, product_id, name, provider, origin, packaging, reference, offer_nb, nomenclature, price, cost_type, quantity, is_confidential)  from '$$PATH$$/2064.dat' ;
--
-- Data for Name: history_history_items; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY history_history_items (id, history_id, orderitem_id) FROM stdin;
\.
copy history_history_items (id, history_id, orderitem_id)  from '$$PATH$$/2065.dat' ;
--
-- Data for Name: infos_info; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY infos_info (id, text, expiry, date_created) FROM stdin;
\.
copy infos_info (id, text, expiry, date_created)  from '$$PATH$$/2069.dat' ;
--
-- Data for Name: issues_issue; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY issues_issue (id, title, description, issue_type, severity, status, date_created, date_closed) FROM stdin;
\.
copy issues_issue (id, title, description, issue_type, severity, status, date_created, date_closed)  from '$$PATH$$/2070.dat' ;
--
-- Data for Name: provider_provider; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY provider_provider (id, name, reseller_id, notes, is_local, is_service) FROM stdin;
\.
copy provider_provider (id, name, reseller_id, notes, is_local, is_service)  from '$$PATH$$/2060.dat' ;
--
-- Data for Name: order_order; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY order_order (id, number, budget_id, team_id, provider_id, status, notes, is_confidential, date_created, date_delivered, last_change) FROM stdin;
\.
copy order_order (id, number, budget_id, team_id, provider_id, status, notes, is_confidential, date_created, date_delivered, last_change)  from '$$PATH$$/2063.dat' ;
--
-- Data for Name: order_order_items; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY order_order_items (id, order_id, orderitem_id) FROM stdin;
\.
copy order_order_items (id, order_id, orderitem_id)  from '$$PATH$$/2062.dat' ;
--
-- Data for Name: product_product; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY product_product (id, provider_id, origin, name, packaging, reference, price, offer_nb, nomenclature, category, sub_category, expiry, last_change) FROM stdin;
\.
copy product_product (id, provider_id, origin, name, packaging, reference, price, offer_nb, nomenclature, category, sub_category, expiry, last_change)  from '$$PATH$$/2061.dat' ;
--
-- Data for Name: provider_provider_users_in_charge; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY provider_provider_users_in_charge (id, provider_id, user_id) FROM stdin;
\.
copy provider_provider_users_in_charge (id, provider_id, user_id)  from '$$PATH$$/2059.dat' ;
--
-- Data for Name: team_teammember; Type: TABLE DATA; Schema: public; Owner: briois
--

COPY team_teammember (id, team_id, user_id, member_type) FROM stdin;
\.
copy team_teammember (id, team_id, user_id, member_type)  from '$$PATH$$/2058.dat' ;
--
-- PostgreSQL database dump complete
--

